import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ecommerce-guest',
  templateUrl: './ecommerce-guest.component.html',
  styleUrls: ['./ecommerce-guest.component.css']
})
export class EcommerceGuestComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
