import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ecommerce-auth',
  templateUrl: './ecommerce-auth.component.html',
  styleUrls: ['./ecommerce-auth.component.css']
})
export class EcommerceAuthComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
