export const environment = {
  production: true,
  URL_BACKEND: 'api.dominio.com/',
  URL_SERVICIOS: 'api.dominio.com/api/',
  URL_FRONTED: 'ecommerce.dominio.com',
};
