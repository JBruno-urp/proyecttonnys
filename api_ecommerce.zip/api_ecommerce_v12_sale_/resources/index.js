import User from './User'

import Categorie from './Categorie'
import Product from './Product'
import Slider from './Slider'
import Cart from './Cart'

export default {
    User,
    Categorie,
    Product,
    Slider,
    Cart,
}